import torch
import torch.nn as nn
from torchsummary import summary


class SeparableConv(nn.Module):
    def __init__(self, in_channels, out_channels, m):
        super().__init__()
        # 1×m卷积
        self.conv_1xm = nn.Conv2d(
            in_channels, out_channels,
            kernel_size=(1, m),
            padding=(0, m // 2)
        )
        # m×1卷积
        self.conv_mx1 = nn.Conv2d(
            in_channels, out_channels,
            kernel_size=(m, 1),
            padding=(m // 2, 0)
        )

        self.c3 = nn.Conv2d(in_channels,out_channels,m,padding=m//2)

    def forward(self, x):
        out_x = self.conv_1xm(x)
        out_y = self.conv_mx1(x)
        out = out_x + out_y
        # out = self.c3(x) # 普通卷积
        return out


# 测试代码
m = 3  # 卷积核宽度/高度（建议奇数）
in_channels = 32
out_channels = 64
batch_size = 16
height = width = 32  # 输入尺寸32×32

# 初始化模型
model = SeparableConv(in_channels, out_channels, m)
input_tensor = torch.randn(batch_size, in_channels, height, width)
output = model(input_tensor)

print(f"输入尺寸: {input_tensor.shape}")
print(f"输出尺寸: {output.shape}")  # 当m为奇数时，尺寸保持不变

input_size = (32, 64, 64)
summary(model, input_size, batch_size=16, device="cpu")  # Adjust the batch_size according to your needs



