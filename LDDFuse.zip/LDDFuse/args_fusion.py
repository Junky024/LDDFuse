import os

# Hyperparameters Setting
class args():

	data_path = 'F:/Datasets/MSRS'
	# detect_path = r'F:\Datasets\MSRS\\'

	# train_IR = train_data_path + 'ir/'
	# train_VIS = train_data_path + 'vi/'
	# train_Label = train_data_path + 'labels'

	# detect_IR = detect_path + 'IR/'
	# detect_VIS = detect_path + 'VIS/'


	train_path = '.\\Train_result\\'
	train_temp_path = '.\\Train_result\\temp\\'
	device = "cuda"

	# training args
	batch_size = 16
	val_batch_size = 50
	epochs = 5
	lr = 2e-4
	dim = 16

	# 定义高斯核的大小和标准差
	kernel_size = (5, 5)
	sigma = 2.0
	# 定义双边滤波的参数
	d = 11
	sigmaColor = 8
	sigmaSpace = 0.05

	# Train_Image_Number = len(os.listdir(train_data_path + 'VIS/VIS'))
	# Iter_per_epoch = Train_Image_Number // batch_size
	# Val_Image_Number = len(os.listdir(train_data_path + 'val/VIS/VIS'))
	# Iter_per_epoch_val = Val_Image_Number // val_batch_size

	# 设置检查点文件路径
	Model_checkpoint_path = train_temp_path + 'model_weight_temp.pkl'

	temp_model_dir = os.path.join(train_temp_path, 'model_weight_temp.pkl') #"path to folder where trained model will be saved."
	save_model_dir = os.path.join(train_path, 'model_weight.pkl') #"path to folder where trained model will be saved."