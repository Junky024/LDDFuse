import torch
from torch import nn

# =========  Cross-Complementary Feature Transformer (C2FT)  ========= #
class C2FT(nn.Module):
    def __init__(self, dim=64):
        super(C2FT, self).__init__()

        self.query_conv_ir = nn.Conv2d(in_channels=dim, out_channels=dim, kernel_size=1)
        self.key_conv_ir   = nn.Conv2d(in_channels=dim, out_channels=dim, kernel_size=1)
        self.value_conv_ir = nn.Conv2d(in_channels=dim, out_channels=dim, kernel_size=1)

        self.query_conv_vis = nn.Conv2d(in_channels=dim, out_channels=dim, kernel_size=1)
        self.key_conv_vis   = nn.Conv2d(in_channels=dim, out_channels=dim, kernel_size=1)
        self.value_conv_vis = nn.Conv2d(in_channels=dim, out_channels=dim, kernel_size=1)


        self.gamma_ir = nn.Parameter(torch.zeros(1)) # 可学习权重，反向传播参数更新时动态调整权重系数
        self.gamma_vis = nn.Parameter(torch.zeros(1))
        self.softmax = nn.Softmax(dim=-1)

        self.relu = nn.ReLU(inplace=True)
        self.sigmoid = nn.Sigmoid()


    def forward(self, ir, vis):

        batchsize, channel, width, height = ir.size()

        query_ir = self.query_conv_ir(ir)  # ir
        key_vis = self.key_conv_vis(vis)
        value_vis = self.value_conv_vis(vis)
        attention_ir = self.softmax(torch.mul(query_ir, key_vis))
        out_ir = torch.mul(value_vis, attention_ir)
        # out_ir = out_ir.view(batchsize, channel, width, height)

        query_vis = self.query_conv_vis(vis)  # vis
        key_ir = self.key_conv_ir(ir)
        value_ir = self.value_conv_ir(ir)
        attention_vis = self.softmax(torch.mul(query_vis, key_ir))
        out_vis = torch.mul(value_ir, attention_vis)
        # out_vis = out_vis.view(batchsize, channel, width, height)

        out_ir = self.relu(self.gamma_ir * out_ir + ir)
        out_vis = self.relu(self.gamma_vis * out_vis + vis)

        return out_ir, out_vis

def count_parameters(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


if __name__ == '__main__':
    f1 = torch.randn((1,64,32,32))
    f2 = torch.randn((1,64,32,32))

    c2ft = C2FT(dim=64)
    ir_out, vis_out = c2ft(f1,f2)
    print('ir_out.shape:', ir_out.shape)
    print('vis_out.shape:', vis_out.shape)

    c2ft.cuda()
    print(f"Total number of trainable parameters: {count_parameters(c2ft)}")
