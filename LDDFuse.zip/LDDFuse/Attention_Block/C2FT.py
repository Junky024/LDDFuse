import torch
import torch.nn as nn

class c2ft(nn.Module):

    def __init__(self, dim, kernel_size=3, factor=4):
        super().__init__()
        self.dim = dim
        self.kernel_size = kernel_size

        self.key_embed_ir = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=kernel_size, padding=1, stride=1, bias=False),
            nn.BatchNorm2d(dim),
            nn.ReLU()
        )
        self.key_embed_vis = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=kernel_size, padding=1, stride=1, bias=False),
            nn.BatchNorm2d(dim),
            nn.ReLU()
        )
        self.value_embed_ir = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size = 1, stride=1, bias=False),  # 1*1的卷积进行Value的编码
            nn.BatchNorm2d(dim)
        )
        self.value_embed_vis = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=1, stride=1, bias=False),  # 1*1的卷积进行Value的编码
            nn.BatchNorm2d(dim)
        )

        self.attention_embed_ir = nn.Sequential(  # 通过连续两个1*1的卷积计算注意力矩阵
            nn.Conv2d(2 * dim, 2 * dim // factor, 1, bias=False),  # 输入concat后的特征矩阵 Channel = 2*C
            nn.BatchNorm2d(2 * dim // factor),
            nn.ReLU(),
            nn.Conv2d(2 * dim // factor, kernel_size * kernel_size * dim, 1, stride=1)  # out: H * W * (K*K*C)
        )
        self.attention_embed_vis = nn.Sequential(  # 通过连续两个1*1的卷积计算注意力矩阵
            nn.Conv2d(2 * dim, 2 * dim // factor, 1, bias=False),  # 输入concat后的特征矩阵 Channel = 2*C
            nn.BatchNorm2d(2 * dim // factor),
            nn.ReLU(),
            nn.Conv2d(2 * dim // factor, kernel_size * kernel_size * dim, 1, stride=1)  # out: H * W * (K*K*C)
        )

        self.gamma_ir = nn.Parameter(torch.zeros(1))  # 可学习权重，反向传播参数更新时动态调整权重系数
        self.gamma_vis = nn.Parameter(torch.zeros(1))
        self.softmax = nn.Softmax(dim=-1)
        self.relu = nn.ReLU(inplace=True)


    def forward(self, ir, vis):
        batchsize, channel, height, width = ir.shape
        k_ir = self.key_embed_ir(ir)
        v_ir = self.value_embed_ir(ir).view(batchsize, channel, -1)

        att_vis = self.attention_embed_vis(torch.cat([k_ir, vis], dim=1))  # shape：batchsize,channel*k*k,height,width  计算注意力矩阵
        att_vis = att_vis.reshape(batchsize, channel, self.kernel_size * self.kernel_size, height, width)
        att_vis = att_vis.mean(2, keepdim=False).view(batchsize, channel, -1)  # shape：batchsize,channel,height*width  求平均降低维度
        out_vis = (self.softmax(att_vis) * v_ir).view(batchsize, channel, height, width)  # 对每一个H*w进行softmax后

        k_vis = self.key_embed_vis(vis)
        v_vis = self.value_embed_vis(vis).view(batchsize, channel, -1)

        att_ir = self.attention_embed_ir(torch.cat([k_vis, ir], dim=1))  # shape：batchsize,channel*k*k,height,width  计算注意力矩阵
        att_ir = att_ir.reshape(batchsize, channel, self.kernel_size * self.kernel_size, height, width)
        att_ir = att_ir.mean(2, keepdim=False).view(batchsize, channel, -1)  # shape：batchsize,channel,height*width  求平均降低维度
        out_ir = (self.softmax(att_ir) * v_vis).view(batchsize, channel, height, width)  # 对每一个H*w进行softmax后

        out_ir = self.relu(self.gamma_ir * out_ir + k_ir)
        out_vis = self.relu(self.gamma_vis * out_vis + k_vis)

        return out_ir, out_vis



































#
# # Multi-Head Attention Block
# class c2ft(nn.Module):
#     def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
#         super().__init__()
#
#         self.dim = dim
#         self.num_heads = num_heads
#         head_dim = dim // num_heads
#
#         self.scale = qk_scale or head_dim ** -0.5
#
#         self.qkv_ir = nn.Conv2d(dim, dim * 3, 1, bias=qkv_bias)
#         self.qkv_vis = nn.Conv2d(dim, dim * 3, 1, bias=qkv_bias)
#
#         self.attn_drop = nn.Dropout(attn_drop)
#
#         self.proj_ir = nn.Conv2d(dim, dim, 1)
#         self.proj_vis = nn.Conv2d(dim, dim, 1)
#
#         self.proj_drop = nn.Dropout(proj_drop)
#
#     def forward(self, ir, vis):
#         B, C, H, W = ir.shape
#         N = H * W
#
#         q_ir, k_ir, v_ir = self.qkv_ir(ir).reshape(B, self.num_heads, C // self.num_heads * 3, N).chunk(3, dim=2)  # (B, num_heads, head_dim, N)
#         q_vis, k_vis, v_vis = self.qkv_vis(vis).reshape(B, self.num_heads, C // self.num_heads * 3, N).chunk(3, dim=2)  # (B, num_heads, head_dim, N)
#
#         attn_ir = (k_vis.transpose(-1, -2) @ q_ir) * self.scale
#         attn_ir = attn_ir.softmax(dim=-2)  # (B, h, N, N)
#         attn_ir = self.attn_drop(attn_ir)
#         out_ir = self.proj_drop(self.proj_ir((v_vis @ attn_ir).reshape(B, C, H, W)))
#
#         attn_vis = (k_ir.transpose(-1, -2) @ q_vis) * self.scale
#         attn_vis = attn_vis.softmax(dim=-2)  # (B, h, N, N)
#         attn_vis = self.attn_drop(attn_vis)
#         out_vis = self.proj_drop(self.proj_vis((v_ir @ attn_vis).reshape(B, C, H, W)))
#
#         return out_ir, out_vis
#



def count_parameters(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

# if __name__ == '__main__':
#     f1 = torch.randn((1,64,32,32))
#     f2 = torch.randn((1,64,32,32))
#
#     c2ft = c2ft(dim=64)
#     ir_out, vis_out = c2ft(f1,f2)
#     print('ir_out.shape:', ir_out.shape)
#     print('vis_out.shape:', vis_out.shape)
#
#     c2ft.cuda()
#     print(f"Total number of trainable parameters: {count_parameters(c2ft)}")
