import torch
import torch.nn as nn

#  LKB, Large Kernel Block
class LKB(nn.Module):
    '''
    LKB学习输入特征的长距离依赖关系，根据输入判别出关键特征并自动忽略噪声。输入特征首先运用两层1×1
    卷积进行降维，然后利用大核注意力获取融合特征的关键信息，最后通过残差连接将降维后的特征与注意力特征结合。
    '''
    def __init__(self, in_ch, out_ch=128, temp_ch=64):
        super(LKB, self).__init__()
        self.C1 = nn.Conv2d(in_ch, out_ch, 1)
        self.DW_C5 = nn.Sequential(
            nn.Conv2d(out_ch, out_ch, 5, groups=out_ch, padding=2),
            nn.Conv2d(out_ch, temp_ch, 1),
        )
        self.DW_C7 = nn.Sequential(
            nn.Conv2d(temp_ch, temp_ch, 7, groups=temp_ch, padding=9, dilation=3),
            nn.Conv2d(temp_ch, temp_ch, 1),
        )
        self.dwC1 = nn.Conv2d(temp_ch,out_ch,1)
        self.relu = nn.ReLU()
    def forward(self, x):
        c1_out = self.relu(self.C1(x))
        dw_c5_out = self.DW_C5(c1_out)
        dw_c7_out = self.DW_C7(dw_c5_out)
        dwc1_out = self.dwC1(dw_c7_out)
        dw_out = torch.mul(c1_out,dwc1_out)
        lkb_out = dw_out + c1_out
        return lkb_out

if __name__ == '__main__':
    f1 = torch.randn([1,128,128,128])
    lkb = LKB(in_ch=128,out_ch=32,temp_ch=64)
    f2 = lkb(f1)
    print(f2.shape)