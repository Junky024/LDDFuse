import torch
from torch import nn
# from attention.CBAM import CBAMBlock
from Attention_Block.CA import CoordAtt

# Attention Fusion Module
class AFMBlock(nn.Module):
    def __init__(self, channel):
        super(AFMBlock, self).__init__()
        # self.att = CBAMBlock(channel=channel,reduction=radio)
        self.att = CoordAtt(inp=channel, oup=channel)
        self.c1_cat = nn.Conv2d(2 * channel, channel, 1)

    def forward(self, x1, x2):
        x1_att = self.att(x1)
        x2_att = self.att(x2)
        complementary_fea = x1_att + x2_att
        common_fea = torch.mul(x1_att,x2_att)
        enhance_fea = torch.cat([complementary_fea,common_fea],dim=1)
        out = self.c1_cat(enhance_fea)

        return out



