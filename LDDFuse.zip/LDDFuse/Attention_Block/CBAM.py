import torch
from torch import nn


#通道注意力
class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=4):
        super(ChannelAttention, self).__init__()
        #平均池化
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        #最大池化
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        
        #MLP  除以16是降维系数
        self.fc1   = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False) #kernel_size=1
        self.relu1 = nn.ReLU()
        self.fc2   = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        #结果相加
        out = avg_out + max_out
        return torch.mul(x,self.sigmoid(out))

#空间注意力
class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()
        #声明卷积核为 3 或 7
        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        #进行相应的same padding填充
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)  #平均池化
        max_out, _ = torch.max(x, dim=1, keepdim=True) #最大池化
        #拼接操作
        w = torch.cat([avg_out, max_out], dim=1)
        w = self.conv1(w) #7x7卷积填充为3，输入通道为2，输出通道为1
        return torch.mul(x,self.sigmoid(w))

#CBAM
class CBAM(nn.Module):
    def __init__(self, dim):
        super(CBAM,self).__init__()
        self.channel_attention = ChannelAttention(in_planes=dim)
        self.spatial_attention = SpatialAttention()

    def forward(self,x):
        channel_attention_out = self.channel_attention(x)
        spatial_attention_out = self.spatial_attention(channel_attention_out)

        return  spatial_attention_out



# if __name__ == "__main__":
#     f1 = torch.randn([64,64,3,3])
#
#
#     channel_attention = ChannelAttention(in_planes=64)
#     out = channel_attention(f1)
#     print("channel_attention_out.shape:",out.shape)
#
#
#     spatial_attention = SpatialAttention()
#     s_out = spatial_attention(out)
#     print("spatial_attention_out.shape:",s_out.shape)
#
#
#     cbam = CBAM(dim=64)
#     out_cbam = cbam(f1)
#     print("CBAM_out.shape:",out_cbam.shape)




