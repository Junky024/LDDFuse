import torch
from torch import nn
import torch.nn.functional as F


# swish激活函数，β=1时近似于relu，一般情况下，β 的值在范围 [0.5, 2.0] 之间是常见的选择。
def swish(x, beta=1.0):
    return x * torch.sigmoid(beta * x)


class CoordAtt(nn.Module):
    def __init__(self, inp, oup, groups=32):
        super(CoordAtt, self).__init__()
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))  # 将[H,W]的特征图保持高度 H 不变，但将宽度 W 调整为1。
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))  # 将[H,W]的特征图保持宽度 W 不变，但将高度 H 调整为1。

        mip = max(8, inp // groups)

        self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        self.conv2 = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
        self.conv3 = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
        # self.relu = h_swish()

    def forward(self, x):
        identity = x
        n, c, h, w = x.size()
        x_h = self.pool_h(x)
        x_w = self.pool_w(x).permute(0, 1, 3, 2)  # 转置：[B,C,H,W] → [B,C,W,H]

        y = torch.cat([x_h, x_w], dim=2)  # y.shpae = [B, C, H+W, 1]
        # print("y.shape:",y.shape)
        y = self.conv1(y)
        y = self.bn1(y)
        # y = self.relu(y)
        y = swish(y)
        x_h, x_w = torch.split(y, [h, w], dim=2)  # 将张量 y 沿着H维度切分为两个子张量 x_h 和 x_w，其中 x_h 的宽度为 h，x_w 的宽度为 w。
        x_w = x_w.permute(0, 1, 3, 2)  # 转置：[B,C,W,H] → [B,C,H,W]

        x_h = self.conv2(x_h).sigmoid()
        x_w = self.conv3(x_w).sigmoid()
        x_h = x_h.expand(-1, -1, h, w)
        x_w = x_w.expand(-1, -1, h, w)

        y = identity * x_w * x_h

        return y



if __name__ == "__main__":
    f1 = torch.randn([1,64,3,4])
    ca = CoordAtt(inp=64, oup=64)
    out = ca(f1)

    print("out.shape:", out.shape)

