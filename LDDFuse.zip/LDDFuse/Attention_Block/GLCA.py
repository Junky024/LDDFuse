import torch
from torch import nn


#全局通道注意力
class Channel_Global_Attention(nn.Module):
    def __init__(self, in_planes, ratio=1):
        super(Channel_Global_Attention, self).__init__()
        #平均池化
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # #最大池化
        # self.max_pool = nn.AdaptiveMaxPool2d(1)
        
        #MLP  除以16是降维系数
        self.fc1 = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False) #kernel_size=1
        self.bn1 = nn.BatchNorm2d(in_planes // ratio)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)
        self.bn2 = nn.BatchNorm2d(in_planes)

    def forward(self, x):
        out = self.bn2(self.fc2(self.relu1(self.bn1(self.fc1(self.avg_pool(x))))))
        # max_out = self.bn2(self.fc2(self.relu1(self.bn1(self.fc1(self.max_pool(x))))))
        #结果相加
        # out = avg_out + max_out
        return out

#局部通道注意力
class Channel_Local_Attention(nn.Module):
    def __init__(self, in_planes, ratio=1):
        super(Channel_Local_Attention, self).__init__()
        # MLP  除以16是降维系数
        self.fc1 = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False)  # kernel_size=1
        self.bn1 = nn.BatchNorm2d(in_planes // ratio)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)
        self.bn2 = nn.BatchNorm2d(in_planes)

    def forward(self, x):
        out = self.bn2(self.fc2(self.relu1(self.bn1(self.fc1(x)))))
        return out




#Global and Local Channel Attention Fusion Module
class GLCA(nn.Module):
    def __init__(self, dim):
        super(GLCA,self).__init__()
        self.g_att = Channel_Global_Attention(in_planes=dim)
        self.l_att = Channel_Local_Attention(in_planes=dim)
        self.sigmoid = nn.Sigmoid()

    def forward(self,x):
        g_att_out = self.g_att(x)
        l_att_out = self.l_att(x)
        out = self.sigmoid(g_att_out+l_att_out)
        return out


class FFB_ATT(nn.Module):
    def __init__(self, dim=32):
        super(FFB_ATT, self).__init__()
        self.glca1 = GLCA(dim=dim)  # output: sigmoid(x)
        self.glca2 = GLCA(dim=dim)
        self.relu = nn.LeakyReLU(negative_slope=0.2)
    def forward(self,x1,x2):
        f1 = x1 + x2
        w1 = self.glca1(f1)
        w2 = 1 - w1
        x1_att = torch.mul(x1,w1)
        x2_att = torch.mul(x2,w2)
        f2 = x1_att + x2_att
        w3 = self.glca2(f2)
        w4 = 1 - w3
        x1_att2 = torch.mul(x1,w3)
        x2_att2 = torch.mul(x2,w4)
        out = x1_att2 + x2_att2
        return out


if __name__ == "__main__":
    f1 = torch.randn([64,64,3,3])
    f2 = torch.randn([64,64,3,3])
    #
    # channel_global_attention = Channel_Global_Attention(in_planes=64)
    # g_out = channel_global_attention(f1)
    # print("channel_global_attention_out.shape:",g_out.shape)
    #
    # channel_local_attention = Channel_Local_Attention(in_planes=64)
    # l_out = channel_local_attention(f1)
    # print("channel_local_attention_out.shape:",l_out.shape)
    #
    #
    # glca = GLCA(dim=64)
    # out_glca = glca(f1)
    # print("GLCA_out.shape:",out_glca.shape)
    #
    # f1_att = torch.mul(f1,out_glca)
    # print("f1_att.shape:",f1_att.shape)

    ffb = FFB_ATT(dim=64)
    ffb_out = ffb(f1,f2)
    print(ffb_out.shape)




