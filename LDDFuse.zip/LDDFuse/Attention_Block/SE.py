import torch
from torch import nn

#  SE Block
class SE_Block(nn.Module):
    def __init__(self, dim):
        super(SE_Block, self).__init__()
        # self.Avgpool = nn.AdaptiveAvgPool2d(1)
        self.Conv1 = nn.Conv2d(dim, dim//16, kernel_size=3,padding=1)
        self.Conv2 = nn.Conv2d(dim//16, dim, kernel_size=3,padding=1)
        self.relu = nn.ReLU(inplace=True)
        self.Sigmoid = nn.Sigmoid()

    def se(self, input):
        x_avgpool = nn.AdaptiveAvgPool2d((1,1))(input)  #[B, C, 1, 1]
        x1 = self.relu(self.Conv1(x_avgpool))
        x2 = self.Conv2(x1)
        x_sigmoid = self.Sigmoid(x2)
        x_out = torch.mul(input, x_sigmoid)
        return x_out

    def forward(self, x):
        x = self.se(x)
        return x