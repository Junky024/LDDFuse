import torch
from torch import nn
from torch.nn import init

class C2SE(nn.Module):
    def __init__(self, dim=64,reduction=8):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Conv2d(dim, dim // reduction, 3, padding=1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(dim // reduction, dim, 3, padding=1, bias=False),
            nn.Sigmoid()
        )
        self.c1_ir = nn.Conv2d(2*dim,dim,1)
        self.c1_vis = nn.Conv2d(2*dim,dim,1)

    def init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                init.kaiming_normal_(m.weight, mode='fan_out')
                if m.bias is not None:
                    init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                init.normal_(m.weight, std=0.001)
                if m.bias is not None:
                    init.constant_(m.bias, 0)

    def forward(self, ir, vis):
        ir_gap = nn.AdaptiveAvgPool2d((1,1))(ir)  #[B, C, 1, 1]
        w_ir = self.fc(ir_gap)
        att_ir = torch.mul(ir,w_ir)  # se_ir

        vis_gap = nn.AdaptiveAvgPool2d((1,1))(vis)  #[B, C, 1, 1]
        w_vis = self.fc(vis_gap)
        att_vis = torch.mul(vis,w_vis)  # se_vis

        w_ir_ = 1 - w_ir
        w_vis_ = 1 - w_vis

        att_ir_ = torch.mul(ir,w_ir_)  # se_ir_
        att_vis_ = torch.mul(vis,w_vis_)  # se_vis_

        att_ir_out = self.c1_ir(torch.concat([att_ir,att_ir_],dim=1))
        att_vis_out = self.c1_vis(torch.concat([att_vis,att_vis_],dim=1))

        return att_ir_out, att_vis_out

# class C2SE(nn.Module):
#     def __init__(self, dim=64,reduction=8):
#         super().__init__()
#         self.avg_pool = nn.AdaptiveAvgPool2d(1)
#         self.fc = nn.Sequential(
#             nn.Linear(dim, dim // reduction, bias=False),
#             nn.ReLU(inplace=True),
#             nn.Linear(dim // reduction, dim, bias=False),
#             nn.Sigmoid()
#         )
#         self.c1_ir = nn.Conv2d(2*dim,dim,1)
#         self.c1_vis = nn.Conv2d(2*dim,dim,1)
#
#     def init_weights(self):
#         for m in self.modules():
#             if isinstance(m, nn.Conv2d):
#                 init.kaiming_normal_(m.weight, mode='fan_out')
#                 if m.bias is not None:
#                     init.constant_(m.bias, 0)
#             elif isinstance(m, nn.BatchNorm2d):
#                 init.constant_(m.weight, 1)
#                 init.constant_(m.bias, 0)
#             elif isinstance(m, nn.Linear):
#                 init.normal_(m.weight, std=0.001)
#                 if m.bias is not None:
#                     init.constant_(m.bias, 0)
#
#     def forward(self, ir, vis):
#         b, c, _, _ = ir.size()
#         ir_gap = self.avg_pool(ir).view(b, c)  # ir全局平局池化
#         w_ir = self.fc(ir_gap).view(b, c, 1, 1)
#         att_ir = ir * w_ir.expand_as(ir)  # se_ir
#
#         vis_gap = self.avg_pool(vis).view(b, c)  # vis全局平局池化
#         w_vis = self.fc(vis_gap).view(b, c, 1, 1)
#         att_vis = vis * w_vis.expand_as(vis)  # se_vis
#
#         w_ir_ = 1 - w_ir
#         w_vis_ = 1 - w_vis
#
#         att_ir_ = ir * w_vis_.expand_as(ir)  # se_ir_
#         att_vis_ = vis * w_ir_.expand_as(vis)  # se_vis_
#
#         att_ir_out = self.c1_ir(torch.concat([att_ir,att_ir_],dim=1))
#         att_vis_out = self.c1_vis(torch.concat([att_vis,att_vis_],dim=1))
#
#         return att_ir_out, att_vis_out


def count_parameters(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


if __name__ == '__main__':
    f1 = torch.randn((1,64,32,32))
    f2 = torch.randn((1,64,32,32))

    c2se = C2SE(dim=64)
    ir_out, vis_out = c2se(f1,f2)
    print('ir_out.shape:', ir_out.shape)
    print('vis_out.shape:', vis_out.shape)

    c2se.cuda()
    print(f"Total number of trainable parameters: {count_parameters(c2se)}")