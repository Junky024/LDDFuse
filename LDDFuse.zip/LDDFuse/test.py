# coding:utf-8
import os
import argparse
# from utils import *
import torch
from torch.utils.data import DataLoader
from dataset import Fusion_dataset
from model import net
from FusionNet import FusionNet
from tqdm import tqdm
import numpy as np
from PIL import Image
from args_fusion import args

def RGB2YCrCb(input_im):
    im_flat = input_im.transpose(1, 3).transpose(
        1, 2).reshape(-1, 3)  # (nhw,c)
    R = im_flat[:, 0]
    G = im_flat[:, 1]
    B = im_flat[:, 2]
    Y = 0.299 * R + 0.587 * G + 0.114 * B
    Cr = (R - Y) * 0.713 + 0.5
    Cb = (B - Y) * 0.564 + 0.5
    Y = torch.unsqueeze(Y, 1)
    Cr = torch.unsqueeze(Cr, 1)
    Cb = torch.unsqueeze(Cb, 1)
    temp = torch.cat((Y, Cr, Cb), dim=1).cuda()
    out = (
        temp.reshape(
            list(input_im.size())[0],
            list(input_im.size())[2],
            list(input_im.size())[3],
            3,
        )
        .transpose(1, 3)
        .transpose(2, 3)
    )
    return out

def YCrCb2RGB(input_im):
    im_flat = input_im.transpose(1, 3).transpose(1, 2).reshape(-1, 3)
    mat = torch.tensor(
        [[1.0, 1.0, 1.0], [1.403, -0.714, 0.0], [0.0, -0.344, 1.773]]
    ).cuda()
    bias = torch.tensor([0.0 / 255, -0.5, -0.5]).cuda()
    temp = (im_flat + bias).mm(mat).cuda()
    out = (
        temp.reshape(
            list(input_im.size())[0],
            list(input_im.size())[2],
            list(input_im.size())[3],
            3,
        )
        .transpose(1, 3)
        .transpose(2, 3)
    )
    return out

# tensor to PIL Image
def tensor2img(img, is_norm=True):
  img = img.cpu().float().numpy()
  if img.shape[0] == 1:
    img = np.tile(img, (3, 1, 1))
  if is_norm:
    img = (img - np.min(img)) / (np.max(img) - np.min(img))
  img = np.transpose(img, (1, 2, 0))  * 255.0
  return img.astype(np.uint8)

def save_img_single(img, name, is_norm=True):
  img = tensor2img(img, is_norm=True)
  img = Image.fromarray(img)
  img.save(name)

# To run, set the fused_dir, and the val path in the TaskFusionDataset.py
def main(ir_dir, vi_dir, save_dir, fusion_model_path):
    fusionmodel = net(16)
    # fusionmodel = FusionNet(output=2)
    device = torch.device("cuda:{}".format(args.gpu) if torch.cuda.is_available() else "cpu")
    fusionmodel.load_state_dict(torch.load(fusion_model_path))
    fusionmodel = fusionmodel.to(device)
    # print('fusionmodel load done!')
    test_dataset = Fusion_dataset('val', ir_path=ir_dir, vi_path=vi_dir)
    test_loader = DataLoader(
        dataset=test_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=True,
        drop_last=False,
    )
    test_loader.n_iter = len(test_loader)
    test_bar = tqdm(test_loader)
    with torch.no_grad():
        for it, (img_vis, img_ir, name) in enumerate(test_bar):
            img_vis = img_vis.to(device)
            img_ir = img_ir.to(device)
            images_vis_ycrcb = RGB2YCrCb(img_vis)

            fused_img = fusionmodel(img_ir, images_vis_ycrcb)
            fusion_ycrcb = torch.cat((fused_img, images_vis_ycrcb[:, 1:2, :, :], images_vis_ycrcb[:, 2:, :, :]), dim=1)
            fused_img = YCrCb2RGB(fusion_ycrcb)
            for k in range(len(name)):
                img_name = name[k]
                save_path = os.path.join(save_dir, img_name)
                save_img_single(fused_img[k, ::], save_path)
                test_bar.set_description('Fusion {0} Sucessfully!'.format(name[k]))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Run LDDFuse with pytorch')

    # parser.add_argument('--model_path', '-M', type=str, default='./model/Fusion/fusion_only_model.pth')
    # parser.add_argument('--save_dir', '-save_dir', type=str, default='./Test_result/fusion_only_model_ch16_detect')
    parser.add_argument('--model_path', '-M', type=str, default='./model/Fusion/fusion_model.pth')
    parser.add_argument('--save_dir', '-save_dir', type=str, default='./Test_result/fusion_model_ch16_β0.2_TNO')

    # parser.add_argument('--ir_dir', '-ir_dir', type=str, default=r'F:\Datasets\MSRS_detect\train\ir')
    # parser.add_argument('--vi_dir', '-vi_dir', type=str, default=r'F:\Datasets\MSRS_detect\train\vi')
    # parser.add_argument('--ir_dir', '-ir_dir', type=str, default=r'F:\Datasets\MSRS_detect\test\ir')
    # parser.add_argument('--vi_dir', '-vi_dir', type=str, default=r'F:\Datasets\MSRS_detect\test\vi')
    parser.add_argument('--ir_dir', '-ir_dir', type=str, default=r'F:\study\experiments\Evaluation-for-Image-Fusion-main\Image\Source-Image\TNO\ir')
    parser.add_argument('--vi_dir', '-vi_dir', type=str, default=r'F:\study\experiments\Evaluation-for-Image-Fusion-main\Image\Source-Image\TNO\vi')
    parser.add_argument('--batch_size', '-B', type=int, default=1)
    parser.add_argument('--gpu', '-G', type=int, default=0)
    parser.add_argument('--num_workers', '-j', type=int, default=4)
    args = parser.parse_args()
    os.makedirs(args.save_dir, exist_ok=True)
    print('| testing %s on GPU #%d with pytorch' % ('LDDFuse', args.gpu))
    main(ir_dir=args.ir_dir, vi_dir=args.vi_dir, save_dir=args.save_dir, fusion_model_path=args.model_path)