# -*- coding: utf-8 -*-
import onnx
import torch
from torch import nn
import torch.nn.functional as F
import numpy as np

from Attention_Block.SE import SE_Block
from torchsummary import summary

import os

# Sobel边缘与纹理提取
class Sobelxy(nn.Module):
    def __init__(self, channels):
        super(Sobelxy, self).__init__()
        kernelx = [[-1, 0, 1],
                   [-2, 0, 2],
                   [-1, 0, 1]]
        kernely = [[1, 2, 1],
                   [0, 0, 0],
                   [-1, -2, -1]]
        # 扩展权重以匹配多通道输入: [channels, 1, 3, 3]
        kernelx = torch.FloatTensor(kernelx).repeat(channels, 1, 1, 1)  # 形状 (channels, 1, 3, 3)
        kernely = torch.FloatTensor(kernely).repeat(channels, 1, 1, 1)
        self.weightx = nn.Parameter(data=kernelx, requires_grad=False)
        self.weighty = nn.Parameter(data=kernely, requires_grad=False)

    def forward(self, x):
        # 输入x形状: [batch_size, channels, H, W]
        sobelx = F.conv2d(x, self.weightx, padding=1, groups=x.size(1))  # groups=channels
        sobely = F.conv2d(x, self.weighty, padding=1, groups=x.size(1))
        return torch.abs(sobelx) + torch.abs(sobely)

# 浅层特征提取SEB
class SEB(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(SEB, self).__init__()
        self.seb = nn.Sequential(
            nn.Conv2d(in_channels, out_channels//2, 3, 1, 1), nn.LeakyReLU(negative_slope=0.2, inplace=True),
            nn.Conv2d(out_channels//2, out_channels, 3, 1, 1), nn.LeakyReLU(negative_slope=0.2, inplace=True),
        )

    def forward(self, x):
        return self.seb(x)

# 基于深度可分离卷积的红外特征增强模块DCB
class DCB(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(DCB, self).__init__()
        self.cr1 = nn.Sequential(nn.Conv2d(in_channels, out_channels, 3, padding=1), nn.LeakyReLU(negative_slope=0.1, inplace=True))
        self.dwconv = nn.Sequential(nn.Conv2d(out_channels, out_channels, 5, padding=2, groups=out_channels),
                                    nn.Conv2d(out_channels,out_channels,1), nn.LeakyReLU(negative_slope=0.1, inplace=True))
        self.sobel = nn.Sequential(Sobelxy(in_channels), nn.Conv2d(in_channels, out_channels, 1))
        self.c1 = nn.Conv2d(out_channels, out_channels, 1)

    def forward(self, x):
        residual = self.sobel(x)
        cr1_out = self.cr1(x)
        cr2_out = self.dwconv(cr1_out)
        out = self.c1(cr1_out + cr2_out + residual)
        return out


class CrossConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel):
        super().__init__()
        # 1×m卷积
        self.conv_1xm = nn.Conv2d(in_channels, out_channels, kernel_size=(1, kernel), padding=(0, kernel // 2), bias=False)
        # m×1卷积
        self.conv_mx1 = nn.Conv2d(in_channels, out_channels, kernel_size=(kernel, 1), padding=(kernel // 2, 0), bias=False)
        # 定义统一的可学习偏置项b
        self.b = nn.Parameter(torch.zeros(1, out_channels, 1, 1))

    def forward(self, x):
        out_x = self.conv_1xm(x)
        out_y = self.conv_mx1(x)
        out = out_x + out_y + self.b
        return out

class FNorm(nn.Module):
    def __init__(self, channels):
        super(FNorm, self).__init__()
        self.conv = nn.Conv2d(
            in_channels=channels,
            out_channels=channels,
            kernel_size=1,
            groups=channels,  # 分组数=通道数，实现通道独立
            bias=True
        )
        # 初始化权重和偏置为0，初始状态等效于恒等映射
        self.conv.weight.data.zero_()
        self.conv.bias.data.zero_()

    def forward(self, x):
        return self.conv(x) + x  # (g_m * f^i_m + b_m) + f^i_m

# 交叉卷积纹理增强模块（CCB）
class CCB(nn.Module):
    def __init__(self, dim):
        super(CCB, self).__init__()
        self.cc = nn.Sequential(CrossConv(dim,dim,3), nn.LeakyReLU(negative_slope=0.1, inplace=True), CrossConv(dim,dim,3))
        self.f_norm = FNorm(dim)
        self.se = SE_Block(dim)

    def forward(self, x):
        residual = x
        main = self.se(self.f_norm(self.cc(x)))
        out = residual + main
        return out

#跨模态特征互补模块（FCB）
class FCB(nn.Module):
    def __init__(self, dim):
        super(FCB, self).__init__()
        self.c3 = nn.Conv2d(2*dim,2*dim,3,1,1)
        self.c_ir = nn.Conv2d(dim,dim,3,1,1)
        self.c_vi = nn.Conv2d(dim,dim,3,1,1)

    def forward(self, ir,vi):
        merge = self.c3(torch.concat([ir, vi], dim=1))
        ir_1,vi_1 = torch.split(merge,merge.size(1)//2,dim=1)
        ir_out = torch.mul(ir,torch.sigmoid(self.c_ir(ir_1)))
        vi_out = torch.mul(vi,torch.sigmoid(self.c_vi(vi_1)))
        return ir_out, vi_out

# 图像重建层RB
class RB(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(RB, self).__init__()
        self.rb = nn.Sequential(
            nn.Conv2d(in_channels, in_channels//2, 3, 1, 1), nn.BatchNorm2d(in_channels//2), nn.LeakyReLU(negative_slope=0.2, inplace=True),
            nn.Conv2d(in_channels//2, in_channels//4, 3, 1, 1), nn.BatchNorm2d(in_channels//4), nn.LeakyReLU(negative_slope=0.2, inplace=True),
            nn.Conv2d(in_channels//4, out_channels, 3, 1, 1), nn.Tanh()
        )
    def forward(self, ir,vi):
        return self.rb(torch.concat([ir, vi], dim=1))/2+0.5  # 调整输出范围到[0,1]

# 网络整体结构
class net(nn.Module):
    def __init__(self, dim=64):
        super(net, self).__init__()
        self.seb_ir = SEB(1, dim)
        self.seb_vi = SEB(1, dim)
        self.dcb1 = DCB(dim, dim)
        self.ccb1 = CCB(dim)
        self.fcb = FCB(dim)
        self.dcb2 = DCB(dim, dim)
        self.ccb2 = CCB(dim)
        self.rb = RB(2*dim, 1)

    def forward(self, ir, vi):
        vi = vi[:,:1]
        ir_shallow_fmap = self.seb_ir(ir)
        vi_shallow_fmap = self.seb_vi(vi)
        ir_deep_fmap1 = self.dcb1(ir_shallow_fmap)
        vi_cross_fmap1 = self.ccb1(vi_shallow_fmap)
        ir_com_fmap, vi_com_fmap = self.fcb(ir_deep_fmap1, vi_cross_fmap1)
        ir_deep_fmap2 = self.dcb2(ir_com_fmap)
        vi_cross_fmap2 = self.ccb2(vi_com_fmap)
        fused_img = self.rb(ir_deep_fmap2,vi_cross_fmap2)

        return fused_img

from thop import profile  # 添加thop库用于计算FLOPs
from tqdm import tqdm  # 导入tqdm库
def measure_performance(model, resolutions, device='cuda', repetitions=100):
    results = {}
    for res in resolutions:
        # 创建测试输入
        dummy_ir = torch.randn(1, 1, res, res).to(device)
        dummy_vi = torch.randn(1, 1, res, res).to(device)

        # ========== 1. 计算FLOPs和参数量 ==========
        flops, params = profile(model, inputs=(dummy_ir, dummy_vi), verbose=False)

        # ========== 2. 测量每帧Runtime ==========
        # 预热GPU
        for _ in range(10):
            _ = model(dummy_ir, dummy_vi)

        # 使用CUDA Event测量
        timings = []
        starter = torch.cuda.Event(enable_timing=True)
        ender = torch.cuda.Event(enable_timing=True)

        with torch.no_grad():
            for _ in tqdm(range(repetitions), desc=f"Testing {res}x{res}"):
                starter.record()
                _ = model(dummy_ir, dummy_vi)
                ender.record()
                torch.cuda.synchronize()
                timings.append(starter.elapsed_time(ender))  # 毫秒

        mean_time = np.mean(timings)
        std_time = np.std(timings)

        results[res] = {
            'FLOPs': flops / 1e9,  # 转换为GFLOPs
            'Params': params / 1e6,  # 转换为MB
            'Runtime': f"{mean_time:.2f} ± {std_time:.2f} ms"
        }
    return results


if __name__ == '__main__':
    model = net(dim=16).cuda()
    input_size = [(1, 512, 512), (1, 512, 512)]
    summary(model, input_size, batch_size=1)  # Adjust the batch_size according to your needs

    # 初始化模型
    model = model.eval()

    # 设置测试参数（与论文Table 9完全一致）
    resolutions = [256, 512]  # 两种分辨率
    repetitions = 100  # 重复次数

    results = measure_performance(model, resolutions, 'cuda', repetitions)

    # ========== 3. 打印表格结果 ==========
    print("\n[结果对比表]")
    print("Resolution | FLOPs(G) | Params(M) | Runtime(ms)")
    print("-" * 50)
    for res in resolutions:
        r = results[res]
        print(f"{res}x{res}\t{r['FLOPs']:.2f}\t{r['Params']:.2f}\t{r['Runtime']}")