import numpy as np
import matplotlib.pyplot as plt

def sigmoid_beta(m, gamma=0.5, m0=33, k=0.2):
    return gamma / (1 + np.exp(-k * (m - m0)))

m = np.linspace(0, 100, 100)
beta = [sigmoid_beta(x) for x in m]

plt.figure(figsize=(10,4))
plt.plot(m, beta, linewidth=3, color='#2c7bb6')
plt.xlabel("Iteration (m)", fontsize=12)
plt.ylabel("β Value", fontsize=12)
plt.title("Adaptive β Schedule (Sigmoid型)", fontsize=14)
plt.grid(alpha=0.3)
plt.axvline(x=33, linestyle='--', color='gray')  # 标记中心点m₀
plt.annotate('m₀=33', xy=(33,0.25), ha='right')
plt.show()