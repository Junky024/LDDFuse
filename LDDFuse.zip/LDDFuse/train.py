import math

import torch
import torchvision
from torch.optim import Adam
import os.path as osp
from args_fusion import args
import os
from model import net
from FusionNet import FusionNet
from PIL import Image
from torchvision import transforms
from torch.utils.data import DataLoader
import numpy as np
import logging
from logger import setup_logger
import time
from dataset import Fusion_dataset
import sys
import datetime
from loss import *

from model_TII import BiSeNet
from cityscapes import CityScapes
from optimizer import Optimizer


def RGB2YCrCb(input_im):
    im_flat = input_im.transpose(1, 3).transpose(
        1, 2).reshape(-1, 3)  # (nhw,c)
    R = im_flat[:, 0]
    G = im_flat[:, 1]
    B = im_flat[:, 2]
    Y = 0.299 * R + 0.587 * G + 0.114 * B
    Cr = (R - Y) * 0.713 + 0.5
    Cb = (B - Y) * 0.564 + 0.5
    Y = torch.unsqueeze(Y, 1)
    Cr = torch.unsqueeze(Cr, 1)
    Cb = torch.unsqueeze(Cb, 1)
    temp = torch.cat((Y, Cr, Cb), dim=1).cuda()
    out = (
        temp.reshape(
            list(input_im.size())[0],
            list(input_im.size())[2],
            list(input_im.size())[3],
            3,
        )
        .transpose(1, 3)
        .transpose(2, 3)
    )
    return out

def YCrCb2RGB(input_im):
    im_flat = input_im.transpose(1, 3).transpose(1, 2).reshape(-1, 3)
    mat = torch.tensor(
        [[1.0, 1.0, 1.0], [1.403, -0.714, 0.0], [0.0, -0.344, 1.773]]
    ).cuda()
    bias = torch.tensor([0.0 / 255, -0.5, -0.5]).cuda()
    temp = (im_flat + bias).mm(mat).cuda()
    out = (
        temp.reshape(
            list(input_im.size())[0],
            list(input_im.size())[2],
            list(input_im.size())[3],
            3,
        )
        .transpose(1, 3)
        .transpose(2, 3)
    )
    return out

def train_seg(i=0, logger=None):
    load_path = './model/Fusion/model_final.pth'
    modelpth = './model'
    Method = 'Fusion'
    modelpth = os.path.join(modelpth, Method)
    os.makedirs(modelpth,  exist_ok=True)
    # if logger == None:
    #     logger = logging.getLogger()
    #     setup_logger(modelpth)

    # dataset
    n_classes = 9
    n_img_per_gpu = args.batch_size
    n_workers = 4
    cropsize = [640, 480]
    dataset = CityScapes('F:/Datasets/MSRS/', cropsize=cropsize, mode='train', Method=Method)
    dataloader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=n_workers,
        pin_memory=True,
        drop_last=True,
    )

    # model
    ignore_idx = 255
    net = BiSeNet(n_classes=n_classes)
    # if i>0:
    net.load_state_dict(torch.load(load_path))
    net.cuda()
    net.train()
    print('Load Pre-trained Segmentation Model:{}!'.format(load_path))
    score_thres = 0.7
    n_min = n_img_per_gpu * cropsize[0] * cropsize[1] // 16
    criteria_p = OhemCELoss(
        thresh=score_thres, n_min=n_min, ignore_lb=ignore_idx)
    criteria_16 = OhemCELoss(
        thresh=score_thres, n_min=n_min, ignore_lb=ignore_idx)
    # optimizer
    momentum = 0.9
    weight_decay = 5e-4
    lr_start = 1e-2
    max_iter = 80000
    power = 0.9
    warmup_steps = 1000
    warmup_start_lr = 1e-5
    # it_start = i*20000
    it_start = 20000
    iter_nums=20000

    optim = Optimizer(
        model=net,
        lr0=lr_start,
        momentum=momentum,
        wd=weight_decay,
        warmup_steps=warmup_steps,
        warmup_start_lr=warmup_start_lr,
        max_iter=max_iter,
        power=power,
        it=it_start,
    )

    # train loop
    msg_iter = 10
    loss_avg = []
    st = glob_st = time.time()
    diter = iter(dataloader)
    epoch = 0
    for it in range(iter_nums):
        try:
            im, lb, _ = next(diter)
            if not im.size()[0] == n_img_per_gpu:
                raise StopIteration
        except StopIteration:
            epoch += 1
            # sampler.set_epoch(epoch)
            diter = iter(dataloader)
            im, lb, _ = next(diter)
        im = im.cuda()
        lb = lb.cuda()
        lb = torch.squeeze(lb, 1)

        optim.zero_grad()
        out, mid = net(im)
        lossp = criteria_p(out, lb)
        loss2 = criteria_16(mid, lb)
        loss = lossp + 0.75 * loss2
        loss.backward()
        optim.step()

        loss_avg.append(loss.item())
        # print training log message
        if (it + 1) % msg_iter == 0:
            loss_avg = sum(loss_avg) / len(loss_avg)

            lr = optim.lr
            ed = time.time()
            t_intv, glob_t_intv = ed - st, ed - glob_st
            eta = int(( max_iter - it) * (glob_t_intv / it))
            eta = str(datetime.timedelta(seconds=eta))
            msg = ', '.join(
                [
                    'it: {it}/{max_it}',
                    'lr: {lr:4f}',
                    'loss: {loss:.4f}',
                    'eta: {eta}',
                    'time: {time:.4f}',
                ]
            ).format(
                it=it_start+it + 1, max_it= max_iter, lr=lr, loss=loss_avg, time=t_intv, eta=eta
            )
            if logger == None:
                logger = logging.getLogger()
                setup_logger(modelpth)
            logger.info(msg)
            loss_avg = []
            st = ed
    # dump the final model
    save_pth = osp.join(modelpth, 'model_final.pth')
    net.cpu()
    state = net.module.state_dict() if hasattr(net, 'module') else net.state_dict()
    torch.save(state, save_pth)
    logger.info(
        'Segmentation Model Training done~, The Model is saved to: {}'.format(
            save_pth)
    )
    logger.info('\n')

def run_fusion():
    fused_dir = 'F:/Datasets/MSRS/Fusion/train'
    os.makedirs(fused_dir, exist_ok=True)
    fusion_model_path = './model/Fusion/fusion_model.pth'
    fusionmodel = net(dim=args.dim).cuda()
    fusionmodel.load_state_dict(torch.load(fusion_model_path))
    fusionmodel.eval()
    print('done!')

    # 加载数据集
    dataset = Fusion_dataset('train')
    # 创建DataLoader
    dataloader = DataLoader(
        dataset=dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=4,
        pin_memory=True,
        drop_last=False,
    )

    with torch.no_grad():
        for it, (vi, ir, label) in enumerate(dataloader):
            vi = vi.cuda()
            ir = ir.cuda()

            # 转换并融合
            images_vis_ycrcb = RGB2YCrCb(vi)
            logits = fusionmodel(images_vis_ycrcb, ir)
            fusion_ycrcb = torch.cat((logits, images_vis_ycrcb[:, 1:2, :, :], images_vis_ycrcb[:, 2:, :, :]), dim=1)
            fusion_image = YCrCb2RGB(fusion_ycrcb)
            fused_image = torch.clamp(fusion_image, 0, 1)

            # 保存结果
            for k in range(len(label)):
                filename = os.path.basename(label[k])
                save_path = os.path.join(fused_dir, filename)
                img_np = fused_image[k].cpu().numpy().transpose(1, 2, 0) * 255
                img_np = img_np.astype(np.uint8)
                Image.fromarray(img_np).save(save_path)
                print(f'Fusion {save_path} Successfully!')

def train_fusion(logger=None):
    modelpth = './model'
    Method = 'Fusion'
    modelpth = os.path.join(modelpth, Method)
    # 加载融合模型
    lr_start = 0.001
    fusionmodel = net(dim=args.dim).cuda()
    # fusionmodel.train()
    optimizer = torch.optim.Adam(fusionmodel.parameters(), lr=lr_start)

    # 新增记录变量
    beta_history = []
    iter_history = []

    # 初始化semantic模型并冻结参数
    n_classes = 9
    segmodel = BiSeNet(n_classes=n_classes)
    save_pth = osp.join(modelpth, 'model_final.pth')
    segmodel.load_state_dict(torch.load(save_pth))
    segmodel.cuda()
    segmodel.eval()
    for p in segmodel.parameters():
        p.requires_grad = False

    if logger == None:
        logger = logging.getLogger()
        setup_logger(modelpth)

    # 加载数据集
    dataset = Fusion_dataset('train_semantic_small')
    # 创建DataLoader
    dataloader = DataLoader(
        dataset=dataset,
        batch_size=args.batch_size,
        shuffle=True, # 打乱数据以提高模型的泛化能力
        num_workers=4, # 增加数据加载线程数
        pin_memory=True,
        drop_last=True,
    )
    dataloader.n_iter = len(dataloader)

    score_thres = 0.7
    ignore_idx = 255
    n_min = 8 * 640 * 480 // 8
    criteria_p = OhemCELoss(
        thresh=score_thres, n_min=n_min, ignore_lb=ignore_idx)
    criteria_16 = OhemCELoss(
        thresh=score_thres, n_min=n_min, ignore_lb=ignore_idx)
    compute_fusion_loss = Fusionloss()

    epoch = 10
    # 新增动态权重参数 (根据论文参数)
    m_0 = (dataloader.n_iter * epoch) // 2  # 控制Sigmoid中心位置
    k = 0.1  # 函数斜率
    gamma = 0.2  # 最大权重上限
    # gamma = 0.4  # 最大权重上限
    st = glob_st = time.time()
    logger.info('Training Fusion Model start~')
    for epo in range(0, epoch):
        lr_start = 0.001
        lr_decay = 0.75
        lr_this_epo = lr_start * lr_decay ** (epo - 1)
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr_this_epo

        for it, (vi, ir, label, name) in enumerate(dataloader):
            fusionmodel.train()
            vi = vi.cuda()
            ir = ir.cuda()
            label = label.cuda()

            # 转换并融合
            images_vis_ycrcb = RGB2YCrCb(vi)
            logits = fusionmodel(ir, images_vis_ycrcb)
            fusion_ycrcb = torch.cat((logits, images_vis_ycrcb[:, 1:2, :, :], images_vis_ycrcb[:, 2:, :, :]), dim=1)
            fusion_image = YCrCb2RGB(fusion_ycrcb)
            fused_image = torch.clamp(fusion_image, 0, 1)
            lb = torch.squeeze(label, 1)
            optimizer.zero_grad()

            # seg loss
            out, mid = segmodel(fused_image)
            lossp = criteria_p(out, lb)
            loss2 = criteria_16(mid, lb)
            seg_loss = lossp + 0.1 * loss2
            # 融合损失
            loss_fusion, loss_in, loss_grad = compute_fusion_loss(images_vis_ycrcb, ir, logits)

            # 计算当前迭代次数（注意+1保证从1开始计数）
            current_iter = dataloader.n_iter * epo + it + 1

            # 动态β计算 -------------------------------------------------
            z = k * (current_iter - m_0)
            sigmoid = 1.0 / (1.0 + math.exp(-z))  # 普通数学运算
            beta = gamma * sigmoid
            # beta = gamma * sigmoid + 0.3
            # 记录数据
            beta_history.append(beta)
            iter_history.append(current_iter)

            # loss_total = loss_fusion + beta * seg_loss
            loss_total = loss_fusion + 0.2 * seg_loss

            loss_total.backward()
            optimizer.step()

            #记录时间和日志（3.25，0：58）
            ed = time.time()
            t_intv, glob_t_intv = ed - st, ed - glob_st
            now_it = dataloader.n_iter * epo + it + 1
            eta = int((dataloader.n_iter * epoch - now_it)
                      * (glob_t_intv / (now_it)))
            eta = str(datetime.timedelta(seconds=eta))
            if now_it % 1 == 0:
                # if num > 0:
                #     loss_seg = seg_loss.item()
                # else:
                #     loss_seg = 0
                msg = ', '.join(
                    [
                        'step: {it}/{max_it}',
                        'loss_total: {loss_total:.4f}',
                        'loss_in: {loss_in:.4f}',
                        'loss_grad: {loss_grad:.4f}',
                        'loss_seg: {loss_seg:.4f}',
                        'eta: {eta}',
                        'time: {time:.4f}',
                    ]
                ).format(
                    it=now_it,
                    max_it=dataloader.n_iter * epoch,
                    loss_total=loss_total.item(),
                    loss_in=loss_in.item(),
                    loss_grad=loss_grad.item(),
                    loss_seg=seg_loss.item(),
                    time=t_intv,
                    eta=eta,
                )
                logger.info(msg)
                st = ed
    fusion_model_file = os.path.join(modelpth, 'fusion_model.pth')
    torch.save(fusionmodel.state_dict(), fusion_model_file)
    logger.info("Fusion Model Save to: {}".format(fusion_model_file))
    logger.info('\n')
    # 记录β的变化情况
    try:
        import matplotlib.pyplot as plt
        plt.figure(figsize=(10, 5))
        plt.plot(iter_history, beta_history, 'b-', linewidth=1)
        plt.title('Beta Value During Training')
        plt.xlabel('Training Iteration')
        plt.ylabel('Beta')
        plt.grid(True)
        plt.savefig('beta_curve.png')
        plt.close()
        print('Beta变化曲线已保存为beta_curve.png')
    except ImportError:
        print('未安装matplotlib，无法生成可视化图表')

def train_fusion_only(logger=None):
    modelpth = './model'
    Method = 'Fusion'
    modelpth = os.path.join(modelpth, Method)
    # 加载融合模型
    lr_start = 0.001
    fusionmodel = net(dim=args.dim).cuda()
    # fusionmodel = FusionNet(output=2).cuda()
    optimizer = torch.optim.Adam(fusionmodel.parameters(), lr=lr_start)

    if logger == None:
        logger = logging.getLogger()
        setup_logger(modelpth)

    # 加载数据集
    dataset = Fusion_dataset('train_semantic_small')
    # 创建DataLoader
    dataloader = DataLoader(
        dataset=dataset,
        batch_size=args.batch_size,
        shuffle=True, # 打乱数据以提高模型的泛化能力
        num_workers=4, # 增加数据加载线程数
        pin_memory=True,
        drop_last=True,
    )
    dataloader.n_iter = len(dataloader)

    compute_fusion_loss = Fusionloss()

    epoch = 10
    st = glob_st = time.time()
    logger.info('Training Fusion Model start~')
    for epo in range(0, epoch):
        lr_start = 0.001
        lr_decay = 0.75
        lr_this_epo = lr_start * lr_decay ** (epo - 1)
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr_this_epo

        for it, (vi, ir, _, _) in enumerate(dataloader):
            fusionmodel.train()
            vi = vi.cuda()
            ir = ir.cuda()

            # 转换并融合
            images_vis_ycrcb = RGB2YCrCb(vi)
            logits = fusionmodel(ir, images_vis_ycrcb)
            optimizer.zero_grad()

            # 融合损失
            loss_fusion, loss_in, loss_grad = compute_fusion_loss(images_vis_ycrcb, ir, logits)
            loss_total = loss_fusion

            loss_total.backward()
            optimizer.step()

            #记录时间和日志（3.25，0：58）
            ed = time.time()
            t_intv, glob_t_intv = ed - st, ed - glob_st
            now_it = dataloader.n_iter * epo + it + 1
            eta = int((dataloader.n_iter * epoch - now_it)
                      * (glob_t_intv / (now_it)))
            eta = str(datetime.timedelta(seconds=eta))
            if now_it % 10 == 0:
                msg = ', '.join(
                    [
                        'step: {it}/{max_it}',
                        'loss_total: {loss_total:.4f}',
                        'loss_in: {loss_in:.4f}',
                        'loss_grad: {loss_grad:.4f}',
                        'eta: {eta}',
                        'time: {time:.4f}',
                    ]
                ).format(
                    it=now_it,
                    max_it=dataloader.n_iter * epoch,
                    loss_total=loss_total.item(),
                    loss_in=loss_in.item(),
                    loss_grad=loss_grad.item(),
                    time=t_intv,
                    eta=eta,
                )
                logger.info(msg)
                st = ed
    fusion_model_file = os.path.join(modelpth, 'fusion_only_model.pth')
    torch.save(fusionmodel.state_dict(), fusion_model_file)
    logger.info("Fusion Model Save to: {}".format(fusion_model_file))
    logger.info('\n')





if __name__ == "__main__":
    logpath = './logs'
    logger = logging.getLogger()
    setup_logger(logpath)
    train_fusion(logger)
    # train_fusion_only(logger)
    print("training Done!")