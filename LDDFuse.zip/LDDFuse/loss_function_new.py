import torch
import torch.nn as nn
import torchvision
import torch.nn.functional as F
import numpy as np


# 定义 VGG16 模型
vgg16 = torchvision.models.vgg16(pretrained=True)

# 获取一个卷积层的输出
class VGG16FeatureExtractor(nn.Module):
    def __init__(self,layer_index):
        super(VGG16FeatureExtractor, self).__init__()
        self.features = nn.Sequential(*list(vgg16.features.children())[:layer_index+1])

    def forward(self, x):
        return self.features(x)


def Per_LOSS(batchimg):
    _, c, h, w = batchimg.size()
    fro_2_norm = torch.sum(batchimg**2, dim=(1, 2, 3))
    loss = fro_2_norm / (h * w * c)
    return loss

class Perceptual_Loss_one(nn.Module):
    def __init__(self, layer_index):
        super(Perceptual_Loss_one, self).__init__()
        self.fmap_x1 = VGG16FeatureExtractor(layer_index).cuda()
        self.fmap_x2 = VGG16FeatureExtractor(layer_index).cuda()
        self.fmap_x1.eval()
        self.fmap_x2.eval()

    def forward(self, x1, x2):
        with torch.no_grad():
            fmap_x1 = self.fmap_x1(x1)
            fmap_x2 = self.fmap_x2(x2)
        loss = Per_LOSS(fmap_x1-fmap_x2)
        return loss


class Perceptual_Loss(nn.Module):
    def __init__(self, layer_indices):
        super(Perceptual_Loss, self).__init__()
        self.fmap_x1 = nn.ModuleList([VGG16FeatureExtractor(layer_index).cuda() for layer_index in layer_indices])
        self.fmap_x2 = nn.ModuleList([VGG16FeatureExtractor(layer_index).cuda() for layer_index in layer_indices])

        for fmap in self.fmap_x1:
            fmap.eval()
        for fmap in self.fmap_x2:
            fmap.eval()

    def forward(self, x1, x2):
        x1 = x1.cuda()
        x2 = x2.cuda()
        with torch.no_grad():
            fmap_x1 = [fmap(x1) for fmap in self.fmap_x1]
            fmap_x2 = [fmap(x2) for fmap in self.fmap_x2]

        loss = torch.mean(sum(Per_LOSS(f1 - f2) for f1, f2 in zip(fmap_x1, fmap_x2)))

        return loss


def sobelxy(x):
    kernelx = [[-1, 0, 1],
               [-2, 0, 2],
               [-1, 0, 1]]
    kernely = [[1, 2, 1],
               [0, 0, 0],
               [-1, -2, -1]]
    kernelx = torch.FloatTensor(kernelx).unsqueeze(0).unsqueeze(0).cuda()
    kernely = torch.FloatTensor(kernely).unsqueeze(0).unsqueeze(0).cuda()

    sobelx = F.conv2d(x, kernelx, padding=1)
    sobely = F.conv2d(x, kernely, padding=1)

    return torch.abs(sobelx) + torch.abs(sobely)


def Gradient_Loss_Max(f,x1,x2):
    _, _, h, w = x1.size()
    gra_f, gra_x1, gra_x2 = sobelxy(f), sobelxy(x1), sobelxy(x2)
    gra_max = torch.max(gra_x1, gra_x2)
    l1_norm = torch.sum(torch.abs(gra_f-gra_max), dim=(2, 3))
    loss = torch.mean(l1_norm) / (h * w)
    return loss

def Gradient_Loss(x1,x2):
    _, _, h, w = x1.size()
    gra_x1, gra_x2 = sobelxy(x1), sobelxy(x2)
    l1_norm = torch.sum(torch.abs(gra_x1-gra_x2), dim=(2, 3))
    loss = torch.mean(l1_norm) / (h * w)
    return loss


def Intensity_Loss_Max(f,x1,x2):
    _, _, h, w = x1.size()
    in_max = torch.max(x1,x2)
    l1_norm = torch.sum(torch.abs(f-in_max), dim=(2, 3))
    loss = torch.mean(l1_norm) / (h * w)
    return loss

def Intensity_Loss(x1,x2):
    _, _, h, w = x1.size()
    l1_norm = torch.sum(torch.abs(x1-x2), dim=(2, 3))
    loss = torch.mean(l1_norm) / (h * w)
    return loss



def ssim_loss(img1, img2, size=11, sigma=1.5):
    channel = img1.size(1)
    window = create_gaussian_window(size, sigma, channel).to(img1.device)
    k1 = 0.01
    k2 = 0.03
    L = 1  # depth of image (255 in case the image has a different scale)
    c1 = (k1 * L) ** 2
    c2 = (k2 * L) ** 2
    mu1 = F.conv2d(img1, window, stride=1, padding=0)
    mu2 = F.conv2d(img2, window, stride=1, padding=0)
    mu1_sq = mu1 * mu1
    mu2_sq = mu2 * mu2
    mu1_mu2 = mu1 * mu2
    sigma1_sq = F.conv2d(img1 * img1, window, stride=1, padding=0) - mu1_sq
    sigma2_sq = F.conv2d(img2 * img2, window, stride=1, padding=0) - mu2_sq
    sigma1_2 = F.conv2d(img1 * img2, window, stride=1, padding=0) - mu1_mu2

    ssim_map = ((2 * mu1_mu2 + c1) * (2 * sigma1_2 + c2)) / ((mu1_sq + mu2_sq + c1) * (sigma1_sq + sigma2_sq + c2))
    value = torch.mean(ssim_map)
    return value


def create_gaussian_window(window_size, sigma, channel):
    coords = torch.arange(window_size).float()
    coords -= window_size // 2

    g = coords.pow(2).div(2. * sigma**2).neg()
    g = torch.exp(g)
    g = g / g.sum()

    window = g.view(1, 1, -1, 1).repeat(1, channel, 1, 1)
    return window














if __name__ == '__main__':
    f1 = torch.randn([32,3,64,64]).cuda()
    f2 = torch.randn([32,3,64,64]).cuda()

    ir = torch.randn([32,1,64,64]).cuda()
    vis = torch.randn([32,1,64,64]).cuda()
    fuse = torch.randn([32,1,64,64]).cuda()

    # 逐层计算然后相加再平均
    # loss = torch.mean(Perceptual_Loss_one(14)(f1, f2) + Perceptual_Loss_one(21)(f1, f2) + Perceptual_Loss_one(28)(f1, f2))
    # print(loss)
    #
    # # 使用数组，高级且高效
    # layer_indices = [14, 21, 28]
    # Loss = Perceptual_Loss(layer_indices=layer_indices)
    # loss_per = Loss(f1,f2)
    # print(loss_per)
    #
    #
    # in_loss = Intensity_Loss(fuse,ir,vis)
    # print(in_loss)
    #
    # grad_loss = Gradient_Loss(fuse,ir,vis)
    # print(grad_loss)

    # ssimloss = ssim_loss(ir,fuse)
    # print(ssimloss)








