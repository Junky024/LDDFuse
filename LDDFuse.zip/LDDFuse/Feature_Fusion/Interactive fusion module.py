import torch
from torch import nn
import torch.nn.functional as F


class FuseModule(nn.Module):
    """ Interactive fusion module"""

    def __init__(self, in_dim=64):
        super(FuseModule, self).__init__()
        self.chanel_in = in_dim

        self.query_conv = nn.Conv2d(in_dim, in_dim, 3, 1, 1, bias=True)
        self.key_conv = nn.Conv2d(in_dim, in_dim, 3, 1, 1, bias=True)

        self.gamma1 = nn.Conv2d(in_dim * 2, 2, 3, 1, 1, bias=True)
        self.gamma2 = nn.Conv2d(in_dim * 2, 2, 3, 1, 1, bias=True)
        self.sig = nn.Sigmoid()
        self.fuse_res = nn.Conv2d(in_dim * 2, in_dim, kernel_size=3, stride=1, padding=1)
        # tail
        self.out_conv = nn.Conv2d(in_dim, 1, kernel_size=3, stride=1, padding=1)
        self.act = nn.Tanh()

    def forward(self, x, prior):
        x_q = self.query_conv(x)
        prior_k = self.key_conv(prior)
        energy = x_q * prior_k
        attention = self.sig(energy)
        attention_x = x * attention
        attention_p = prior * attention

        x_gamma = self.gamma1(torch.cat((x, attention_x), dim=1))
        x_out = x * x_gamma[:, [0], :, :] + attention_x * x_gamma[:, [1], :, :]

        p_gamma = self.gamma2(torch.cat((prior, attention_p), dim=1))
        prior_out = prior * p_gamma[:, [0], :, :] + attention_p * p_gamma[:, [1], :, :]

        fuse_feats = self.fuse_res(torch.concat([x_out, prior_out], 1))
        out = self.out_conv(fuse_feats)
        out = self.act(out)

        return out

if __name__ == "__main__":
  f1 = torch.randn([1,64,128,128])
  print(f1.shape)
  
  fuse = FuseModule(in_dim=64)
  f1_out = fuse(f1,f1)
  print(f1_out.shape)