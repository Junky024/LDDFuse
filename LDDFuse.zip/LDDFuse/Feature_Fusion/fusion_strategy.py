import torch
import torch.nn.functional as F


# 特征融合块
def Feature_fusion(fea_ir,fea_vis):
    B,C,H,W = fea_ir.size()
    g_ir = F.adaptive_avg_pool2d(fea_ir,(1,1))
    g_vis = F.adaptive_avg_pool2d(fea_vis,(1,1))
    w_ir = g_ir / (g_ir + g_vis)
    w_vis = g_vis / (g_ir + g_vis)
    F_CA = fea_ir * w_ir + fea_vis * w_vis

    # 计算L1范数
    l1_ir = torch.sum(torch.abs(fea_ir), dim=1, keepdim=True)  # 在通道维度上求和，得到B×1×H×W的L1范数图
    # 计算权重，应用Softmax
    # att_ir_h = F.softmax(l1_ir, dim=2)  # 在H和W维度上应用Softmax，得到注意力权重图，大小仍为B×1×H×W
    # att_ir_w = F.softmax(l1_ir, dim=3)  # 在H和W维度上应用Softmax，得到注意力权重图，大小仍为B×1×H×W
    # att_ir = att_ir_h * att_ir_w
    l1_ir_flatten = l1_ir.view(B,H*W)
    att_ir_flatten = F.softmax(l1_ir_flatten,dim=1)
    att_ir = att_ir_flatten.view(B, 1, H, W)

    l1_vis = torch.sum(torch.abs(fea_vis), dim=1, keepdim=True)
    # 计算权重，应用Softmax
    # att_vis_h = F.softmax(l1_vis, dim=2)  # 在H和W维度上应用Softmax，得到注意力权重图，大小仍为B×1×H×W
    # att_vis_w = F.softmax(l1_vis, dim=3)  # 在H和W维度上应用Softmax，得到注意力权重图，大小仍为B×1×H×W
    # att_vis = att_vis_h * att_vis_w
    l1_vis_flatten = l1_vis.view(B,H*W)
    att_vis_flatten = F.softmax(l1_vis_flatten,dim=1)
    att_vis = att_vis_flatten.view(B, 1, H, W)

    # 加权融合
    F_SA = fea_ir * att_ir + fea_vis * att_vis # 将输入特征图与注意力权重相乘，调整特征图

    fused = (F_CA + F_SA)
    return fused