from model import net
import os
import numpy as np
from utils.Evaluator import Evaluator
import torch
import torch.nn as nn
from utils.img_read_save import img_save,image_read_cv2
import warnings
import logging
import torch.nn.functional as F
import cv2

warnings.filterwarnings("ignore")
logging.basicConfig(level=logging.CRITICAL)

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
Model_path="./model/Fusion/fusion_model.pth"
is_cuda = True
# 定义高斯核的大小和标准差
kernel_size = (5, 5)  # 可以根据需要调整
sigma = 1.0  # 可以根据需要调整

def GaussianBlur(image):
    image = np.array(image)  # 转换为NumPy数组
    blurred = cv2.GaussianBlur(image, kernel_size, sigma)
    image_d = image - blurred
    return image_d

for dataset_name in ["TNO","RoadScene"]:
    print("\n"*2+"="*80)
    model_name="XXXFuse    "
    print("The test result of "+dataset_name+' :')
    test_folder=os.path.join('test_img',dataset_name) 
    test_out_folder=os.path.join('Test_eval',dataset_name)

    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    Model = net(dim=32).to(device)


    Model.load_state_dict(torch.load(Model_path))
    Model.eval()


    with torch.no_grad():
        for img_name in os.listdir(os.path.join(test_folder,"ir")):
            # data_IR=image_read_cv2(os.path.join(test_folder,"ir",img_name),mode='GRAY')[np.newaxis,np.newaxis, ...]/255.0
            # data_VIS = image_read_cv2(os.path.join(test_folder,"vi",img_name), mode='GRAY')[np.newaxis,np.newaxis, ...]/255.0
            #
            # data_IR,data_VIS = torch.FloatTensor(data_IR),torch.FloatTensor(data_VIS)
            # data_VIS, data_IR = data_VIS.cuda(), data_IR.cuda()

            data_IR = np.array(image_read_cv2(os.path.join(test_folder, "ir", img_name), mode='GRAY'), dtype='float32') / 255
            data_IR_crop = data_IR[:(data_IR.shape[0] // 8) * 8, :(data_IR.shape[1] // 8) * 8]
            data_IR_resize = torch.from_numpy(data_IR_crop.reshape((1, 1, data_IR_crop.shape[0], data_IR_crop.shape[1]))).cuda()

            data_VIS = np.array(image_read_cv2(os.path.join(test_folder, "vi", img_name), mode='GRAY'), dtype='float32') / 255
            data_VIS_crop = data_VIS[:(data_VIS.shape[0] // 8) * 8, :(data_VIS.shape[1] // 8) * 8]
            data_VIS_resize = torch.from_numpy(data_VIS_crop.reshape((1, 1, data_VIS_crop.shape[0], data_VIS_crop.shape[1]))).cuda()

            data_IR_D = GaussianBlur(data_IR_crop)
            data_IR_D_resize = torch.from_numpy(data_IR_D.reshape((1, 1, data_IR_crop.shape[0], data_IR_crop.shape[1]))).cuda()

            data_VIS_D = GaussianBlur(data_VIS_crop)
            data_VIS_D_resize = torch.from_numpy(data_VIS_D.reshape((1, 1, data_VIS_crop.shape[0], data_VIS_crop.shape[1]))).cuda()

            # data_Fuse,_,_,_,_ = Model(data_IR_resize,data_VIS_resize,data_IR_D_resize, data_VIS_D_resize)
            data_Fuse = Model(data_IR_resize,data_VIS_resize,data_IR_D_resize, data_VIS_D_resize)

            data_Fuse=(data_Fuse-torch.min(data_Fuse))/(torch.max(data_Fuse)-torch.min(data_Fuse))
            fi = np.squeeze((data_Fuse * 255).cpu().numpy())
            img_save(fi, img_name.split(sep='.')[0], test_out_folder)

    eval_folder=test_out_folder  
    ori_img_folder=test_folder

    metric_result = np.zeros((8))

    for img_name in os.listdir(os.path.join(ori_img_folder, "ir")):
        ir = image_read_cv2(os.path.join(ori_img_folder, "ir", img_name), 'GRAY')
        ir_ = ir[:(ir.shape[0]//8)*8,:(ir.shape[1]//8)*8]
        vi = image_read_cv2(os.path.join(ori_img_folder, "vi", img_name), 'GRAY')
        vi_ = vi[:(vi.shape[0]//8)*8,:(vi.shape[1]//8)*8]
        fi = image_read_cv2(os.path.join(eval_folder, img_name.split('.')[0] + ".png"), 'GRAY')
        metric_result += np.array([Evaluator.EN(fi), Evaluator.SD(fi)
                                      , Evaluator.SF(fi), Evaluator.MI(fi, ir_, vi_)
                                      , Evaluator.SCD(fi, ir_, vi_), Evaluator.VIFF(fi, ir_, vi_)
                                      , Evaluator.Qabf(fi, ir_, vi_), Evaluator.SSIM(fi, ir_, vi_)])

    metric_result /= len(os.listdir(eval_folder))
    print("\t\t    EN\t    SD\t    SF\t    MI\t    SCD\t    VIF\t    Qabf\tSSIM")
    print(model_name + '\t' + str(np.round(metric_result[0], 2)) + '\t'
          + str(np.round(metric_result[1], 2)) + '\t'
          + str(np.round(metric_result[2], 2)) + '\t'
          + str(np.round(metric_result[3], 2)) + '\t'
          + str(np.round(metric_result[4], 2)) + '\t'
          + str(np.round(metric_result[5], 2)) + '\t'
          + str(np.round(metric_result[6], 2)) + '\t'
          + str(np.round(metric_result[7], 2))
          )
    print("=" * 80)