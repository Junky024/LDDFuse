# coding:utf-8
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from torchsummary import summary


class FusionNet(nn.Module):
    def __init__(self, output=2):
        super(FusionNet, self).__init__()
        self.conv1 = nn.Conv2d(2, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.conv3 = nn.Conv2d(64, 32, kernel_size=3, padding=1)
        self.conv4 = nn.Conv2d(32, output, kernel_size=3, padding=1)
        self.sigmoid = nn.Sigmoid()
    def forward(self, image_ir,image_vis):
        # split data into RGB and INF
        x = torch.cat([image_vis[:, :1],image_ir],dim=1)
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        x = self.sigmoid(x)
        w_ir = x[:, :1]
        w_vi = x[:, 1:]
        x_if = w_ir*image_ir + w_vi*image_vis[:, :1] # Weighted avg
        x_if = (x_if - torch.min(x_if)) / (torch.max(x_if) - torch.min(x_if)) #Normalize
        return x_if

if __name__ == '__main__':
    model = FusionNet(output=2).cuda()
    input_size = [(1, 640, 640), (1, 640, 640)]
    summary(model, input_size, batch_size=1)  # Adjust the batch_size according to your needs